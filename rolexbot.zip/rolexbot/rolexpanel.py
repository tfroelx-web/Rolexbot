# ============================================================
# SIR ROLEX STORE - BOLD ITALIC BUILD
# ============================================================
import sqlite3, json, time, re, os, sys, math, random
from datetime import datetime, timedelta, timezone
import requests, telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import logging, html

BOT_TOKEN = "8836459407:AAHilhdApmJtjQxJlyFX8hfYwlCVs7TOoO4"
ADMIN_ID = 8413612683
BRAND = "SIR ROLEX STORE"
SUCCESS_IMG = "https://i.postimg.cc/yNZJYsNN/7564ae47-3cf8-4ed1-8ae3-9bf993332966.png"
CONTACT = "@ETROLEX"
DB_FILE = "sirrolex.db"

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(message)s')
log = logging.getLogger("bot")
bot = telebot.TeleBot(BOT_TOKEN, threaded=True)

def esc(t): return html.escape(str(t)) if t is not None else ""
def now(): return datetime.now(timezone.utc).replace(tzinfo=None)
def nows(): return now().strftime('%Y-%m-%d %H:%M:%S')

def send(cid, text, mk=None):
    try: return bot.send_message(cid, text, parse_mode="HTML", reply_markup=mk)
    except:
        try: return bot.send_message(cid, text, reply_markup=mk)
        except Exception as e: log.error(f"send: {e}")

def nav(call, text, mk=None):
    try: bot.answer_callback_query(call.id)
    except: pass
    try:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=mk)
    except Exception as e:
        if "not modified" in str(e).lower(): return
        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=mk)
        except: pass

def db():
    c = sqlite3.connect(DB_FILE, check_same_thread=False, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    return c

def init_db():
    c = db(); cur = c.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT, balance INTEGER DEFAULT 0, banned INTEGER DEFAULT 0, is_reseller INTEGER DEFAULT 0, total_orders INTEGER DEFAULT 0, total_spent INTEGER DEFAULT 0, joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, category TEXT DEFAULT 'general', api_pid TEXT, api_url TEXT, api_key TEXT, master_key TEXT, tutorial TEXT, download TEXT, demo TEXT, features TEXT, stock INTEGER DEFAULT -1, status TEXT DEFAULT 'active', created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, duration TEXT, price INTEGER, reseller_price INTEGER)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS txs(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, amount INTEGER, type TEXT, details TEXT, key TEXT, product TEXT, duration TEXT, created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS deposits(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, amount INTEGER, utr TEXT, ss TEXT, status TEXT DEFAULT 'pending', reason TEXT, created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, subject TEXT, message TEXT, reply TEXT, status TEXT DEFAULT 'open', created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS coupons(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, discount INTEGER, max_uses INTEGER DEFAULT 1, used INTEGER DEFAULT 0, active INTEGER DEFAULT 1, created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, category TEXT DEFAULT 'project', price INTEGER, description TEXT, file_id TEXT, created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS faqs(id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT, answer TEXT, order_num INTEGER DEFAULT 0)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1), badge TEXT DEFAULT 'TRUSTED • VERIFIED • FAST', welcome TEXT, upi TEXT DEFAULT 'laskarsumona85@okicici', support_name TEXT DEFAULT 'Sir Rolex Support', support_url TEXT DEFAULT 'https://t.me/ETROLEX', update_channel TEXT DEFAULT 'https://t.me/ETROLEX', selling_proof TEXT DEFAULT 'https://t.me/ETROLEX', tutorial_video TEXT DEFAULT '', api_url TEXT, api_key TEXT, master_key TEXT, fg_key TEXT, fg_on TEXT DEFAULT 'off', ai TEXT DEFAULT 'groq', groq TEXT, gemini TEXT, openai TEXT, menu TEXT, maint TEXT DEFAULT 'off', min_dep INTEGER DEFAULT 10, reseller_fee INTEGER DEFAULT 399)""")
    cur.execute("INSERT OR IGNORE INTO settings(id) VALUES(1)")
    cur.execute("SELECT COUNT(*) as c FROM faqs")
    if cur.fetchone()["c"] == 0:
        for i, (q, a) in enumerate([("How to add balance?","Go to Add Balance → Pay via UPI → Send screenshot and UTR"),("How will I get my key?","Key is delivered instantly after purchase"),("Do you offer refunds?","No refunds. Failed purchases are auto-refunded"),("Key not working?","Contact support and create a ticket"),("How to become reseller?","Send reseller request from menu")], 1):
            cur.execute("INSERT INTO faqs(question,answer,order_num) VALUES(?,?,?)", (q, a, i))
    c.commit(); c.close()
    log.info("DB ready")

def gs(k, d=None):
    try:
        c = db(); cur = c.cursor()
        cur.execute(f"SELECT {k} FROM settings WHERE id=1")
        r = cur.fetchone(); c.close()
        return r[k] if r and r[k] is not None else d
    except: return d

def ss(k, v):
    try:
        c = db(); cur = c.cursor()
        cur.execute(f"UPDATE settings SET {k}=? WHERE id=1", (v,))
        c.commit(); c.close(); return True
    except: return False

def is_admin(uid): return uid == ADMIN_ID

def is_banned(uid):
    try:
        c = db(); cur = c.cursor()
        cur.execute("SELECT banned FROM users WHERE id=?", (uid,))
        r = cur.fetchone(); c.close()
        return r and r["banned"] == 1
    except: return False

def is_res(uid):
    try:
        c = db(); cur = c.cursor()
        cur.execute("SELECT is_reseller FROM users WHERE id=?", (uid,))
        r = cur.fetchone(); c.close()
        return r and r["is_reseller"] == 1
    except: return False

ST = {}
def sst(uid, s): ST[uid] = (s, time.time())
def gst(uid):
    v = ST.get(uid)
    if not v: return {}
    if time.time() - v[1] > 1800: ST.pop(uid, None); return {}
    return v[0]
def pst(uid): ST.pop(uid, None)

# ============ MENU with BOLD ITALIC ============
DEF_MENU = [
    {"id":"shop","e":"🔑","l":"𝑺𝒉𝒐𝒑 𝑲𝒆𝒚","s":"danger"},
    {"id":"profile","e":"👤","l":"𝑴𝒚 𝑷𝒓𝒐𝒇𝒊𝒍𝒆","s":"primary"},
    {"id":"add_bal","e":"💰","l":"𝑨𝒅𝒅 𝑩𝒂𝒍𝒂𝒏𝒄𝒆","s":"success"},
    {"id":"orders","e":"📜","l":"𝑨𝒍𝒍 𝑯𝒊𝒔𝒕𝒐𝒓𝒚","s":"primary"},
    {"id":"tutorial","e":"🎬","l":"𝑻𝒖𝒕𝒐𝒓𝒊𝒂𝒍","s":"danger"},
    {"id":"reseller","e":"🤝","l":"𝑩𝒆𝒄𝒐𝒎𝒆 𝑹𝒆𝒔𝒆𝒍𝒍𝒆𝒓","s":"success"},
    {"id":"selling_proof","e":"📸","l":"𝑺𝒆𝒍𝒍𝒊𝒏𝒈 𝑷𝒓𝒐𝒐𝒇","s":"danger"},
    {"id":"support","e":"📞","l":"𝑺𝒖𝒑𝒑𝒐𝒓𝒕","s":"success"},
    {"id":"faq","e":"❓","l":"𝑭𝑨𝑸","s":"primary"},
    {"id":"referral","e":"🎁","l":"𝑹𝒆𝒇𝒆𝒓𝒓𝒂𝒍","s":"success"},
    {"id":"ai","e":"🤖","l":"𝑺𝒊𝒓 𝑹𝒐𝒍𝒆𝒙 𝑨𝑰","s":"primary"},
    {"id":"projects","e":"📁","l":"𝑩𝒖𝒚 𝑷𝒓𝒐𝒋𝒆𝒄𝒕","s":"danger"},
    {"id":"configs","e":"⚙️","l":"𝑩𝒖𝒚 𝑪𝒐𝒏𝒇𝒊𝒈","s":"danger"},
    {"id":"spin","e":"🎮","l":"𝑳𝒖𝒄𝒌𝒚 𝑺𝒑𝒊𝒏","s":"success"},
]

def get_menu():
    raw = gs("menu")
    if raw:
        try:
            m = json.loads(raw)
            if m: return m
        except: pass
    return list(DEF_MENU)

def set_menu(m): ss("menu", json.dumps(m))

def welcome_text(uid):
    c = db(); cur = c.cursor()
    cur.execute("SELECT username,balance,total_orders FROM users WHERE id=?", (uid,))
    u = cur.fetchone(); c.close()
    nm = (u["username"] if u and u["username"] else "User")
    bal = u["balance"] if u else 0
    ors = u["total_orders"] if u else 0
    badge = gs("badge", "TRUSTED • VERIFIED • FAST")
    custom = gs("welcome")
    if custom:
        try:
            return custom.replace("{name}", esc(nm)).replace("{id}", str(uid)).replace("{bal}", str(bal)).replace("{orders}", str(ors))
        except: pass
    return f"""🏪 <b>{BRAND}</b> 🏪
━━━━━━━━━━━━━━━━━━━━━

  <i>✦ {esc(badge)} ✦</i>

━━━━━━━━━━━━━━━━━━━━━

👋 <b>Welcome, <i>{esc(nm)}</i>!</b>

🆔 <b>User ID:</b> <code>{uid}</code>
💰 <b>Balance:</b> <code>₹{bal}</code>
📦 <b>Orders:</b> <code>{ors}</code>

━━━━━━━━━━━━━━━━━━━━━

🚀 <b>Tap below to start shopping!</b>"""

def main_menu(uid):
    menu = get_menu()
    m = InlineKeyboardMarkup(row_width=2)
    rows = []
    for b in menu:
        bid = b.get("id","")
        e = b.get("e","✦"); l = b.get("l",""); s = b.get("s","primary")
        if bid == "spin" and is_res(uid): continue
        if bid == "reseller" and is_res(uid):
            rows.append((e, "𝑹𝒆𝒔𝒆𝒍𝒍𝒆𝒓 𝑷𝒂𝒏𝒆𝒍", "reseller_panel", s)); continue
        rows.append((e, l, bid, s))
    i = 0
    while i < len(rows):
        if i+1 < len(rows):
            m.add(InlineKeyboardButton(f"{rows[i][0]} {rows[i][1]}", callback_data=rows[i][2], style=rows[i][3]),
                  InlineKeyboardButton(f"{rows[i+1][0]} {rows[i+1][1]}", callback_data=rows[i+1][2], style=rows[i+1][3]))
            i += 2
        else:
            m.add(InlineKeyboardButton(f"{rows[i][0]} {rows[i][1]}", callback_data=rows[i][2], style=rows[i][3]))
            i += 1
    if is_admin(uid):
        m.add(InlineKeyboardButton("⚙️ 𝑨𝒅𝒎𝒊𝒏 𝑷𝒂𝒏𝒆𝒍", callback_data="admin", style="primary"))
    return m

def admin_menu(uid):
    m = InlineKeyboardMarkup(row_width=2)
    m.add(InlineKeyboardButton("📦 𝑷𝒓𝒐𝒅𝒖𝒄𝒕𝒔", callback_data="ap", style="primary"),
          InlineKeyboardButton("💰 𝑫𝒆𝒑𝒐𝒔𝒊𝒕𝒔", callback_data="ad", style="success"))
    m.add(InlineKeyboardButton("👥 𝑼𝒔𝒆𝒓𝒔", callback_data="au", style="primary"),
          InlineKeyboardButton("💬 𝑻𝒊𝒄𝒌𝒆𝒕𝒔", callback_data="atk", style="success"))
    m.add(InlineKeyboardButton("🎟️ 𝑪𝒐𝒖𝒑𝒐𝒏𝒔", callback_data="acp", style="primary"),
          InlineKeyboardButton("📁 𝑷𝒓𝒐𝒋𝒆𝒄𝒕𝒔", callback_data="aprj", style="primary"))
    m.add(InlineKeyboardButton("📝 𝑭𝑨𝑸𝒔", callback_data="afaq", style="primary"),
          InlineKeyboardButton("🎛️ 𝑴𝒆𝒏𝒖 𝑬𝒅𝒊𝒕𝒐𝒓", callback_data="am", style="primary"))
    m.add(InlineKeyboardButton("📝 𝑻𝒆𝒙𝒕 𝑬𝒅𝒊𝒕𝒐𝒓", callback_data="atx", style="primary"),
          InlineKeyboardButton("🔌 𝑨𝑷𝑰 𝑺𝒆𝒕𝒕𝒊𝒏𝒈𝒔", callback_data="aapi", style="danger"))
    m.add(InlineKeyboardButton("🤖 𝑨𝑰 𝑪𝒐𝒏𝒕𝒓𝒐𝒍", callback_data="aai", style="primary"),
          InlineKeyboardButton("⚙️ 𝑺𝒆𝒕𝒕𝒊𝒏𝒈𝒔", callback_data="as", style="primary"))
    m.add(InlineKeyboardButton("📢 𝑩𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕", callback_data="abc", style="primary"),
          InlineKeyboardButton("📊 𝑨𝒏𝒂𝒍𝒚𝒕𝒊𝒄𝒔", callback_data="aan", style="primary"))
    m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
    return m

def ahead():
    c = db(); cur = c.cursor()
    cur.execute("SELECT COUNT(*) as c FROM users"); u = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) as c FROM txs WHERE type='purchase'"); o = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) as c FROM deposits WHERE status='pending'"); p = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) as c FROM tickets WHERE status='open'"); t = cur.fetchone()["c"]
    c.close()
    return f"""⚙️ <b>Admin Panel</b>
━━━━━━━━━━━━━━━

👥 <b>Total Users:</b> {u}
📦 <b>Total Orders:</b> {o}
⏳ <b>Pending Deposits:</b> {p}
🎫 <b>Open Tickets:</b> {t}

━━━━━━━━━━━━━━━"""

def ai_call(q):
    try:
        a = gs("ai", "groq")
        if a == "groq" and gs("groq"):
            r = requests.post("https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization": f"Bearer {gs('groq')}", "Content-Type": "application/json"},
                json={"model":"llama-3.3-70b-versatile","messages":[{"role":"system","content":f"You are {BRAND} assistant. Reply short in Hinglish."},{"role":"user","content":q}],"max_tokens":300}, timeout=20)
            if r.status_code == 200: return r.json()["choices"][0]["message"]["content"]
        elif a == "gemini" and gs("gemini"):
            r = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gs('gemini')}", json={"contents":[{"parts":[{"text":q}]}]}, timeout=20)
            if r.status_code == 200: return r.json()["candidates"][0]["content"]["parts"][0]["text"]
        elif a == "openai" and gs("openai"):
            r = requests.post("https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {gs('openai')}", "Content-Type": "application/json"},
                json={"model":"gpt-4o-mini","messages":[{"role":"user","content":q}],"max_tokens":300}, timeout=20)
            if r.status_code == 200: return r.json()["choices"][0]["message"]["content"]
    except Exception as e: log.error(f"ai: {e}")
    return None

@bot.message_handler(commands=['start'])
def cmd_start(m):
    uid = m.from_user.id
    if is_banned(uid): send(m.chat.id, "🚫 <b>Access Denied</b>"); return
    c = db(); cur = c.cursor()
    cur.execute("INSERT OR IGNORE INTO users(id,username) VALUES(?,?)", (uid, m.from_user.username))
    if m.from_user.username: cur.execute("UPDATE users SET username=? WHERE id=?", (m.from_user.username, uid))
    c.commit(); c.close()
    if gs("maint","off") == "on" and not is_admin(uid):
        send(m.chat.id, "🔧 <b>Maintenance Mode</b>\n\n━━━━━━━━━━━━━━━\n\nBot is under maintenance. Please try again later.\n\n━━━━━━━━━━━━━━━"); return
    send(m.chat.id, welcome_text(uid), main_menu(uid))

@bot.message_handler(content_types=['photo'])
def on_photo(m):
    uid = m.from_user.id
    st = gst(uid); a = st.get("a")
    if a == "dep_ss":
        st["ss"] = m.photo[-1].file_id; st["a"] = "dep_amt"; sst(uid, st)
        send(m.chat.id, "✅ <b>Screenshot Received</b>\n\n━━━━━━━━━━━━━━━\n\n<b>Step 2 of 3 — Amount</b>\n\nEnter the amount you paid.\n<i>Example: 100, 500</i>\n\n━━━━━━━━━━━━━━━")

@bot.message_handler(content_types=['document'])
def on_doc(m):
    uid = m.from_user.id
    st = gst(uid)
    if st.get("a") == "restore" and is_admin(uid):
        try:
            fi = bot.get_file(m.document.file_id); data = bot.download_file(fi.file_path)
            if not data.startswith(b"SQLite format 3\x00"): send(m.chat.id, "❌ Invalid"); pst(uid); return
            with open(DB_FILE, 'wb') as f: f.write(data)
            pst(uid); send(m.chat.id, "✅ Database Restored")
        except Exception as e: send(m.chat.id, f"❌ {e}")
        return
    if st.get("a") == "project_file" and is_admin(uid):
        st["pfid"] = m.document.file_id; st["a"] = "project_name"; sst(uid, st)
        send(m.chat.id, "✅ File received!\n\n<b>Now enter project name:</b>"); return

@bot.message_handler(func=lambda m: m.text and not m.text.startswith('/'))
def on_text(m):
    uid = m.from_user.id
    t = (m.text or "").strip()
    st = gst(uid); a = st.get("a", "")
    if is_banned(uid): return

    if a == "dep_amt":
        try:
            amt = int(t); md = int(gs("min_dep", 10))
            if amt < md or amt > 500000: send(m.chat.id, f"❌ Min ₹{md}, max ₹5,00,000"); return
            st["amt"] = amt; st["a"] = "dep_utr"; sst(uid, st)
            send(m.chat.id, f"✅ <b>Amount: ₹{amt}</b>\n\n━━━━━━━━━━━━━━━\n\n<b>Step 3 of 3 — UTR</b>\n\nSend your UTR number.\n<i>UPI app → History → Transaction → Copy 12-digit UTR</i>\n\n━━━━━━━━━━━━━━━")
        except: send(m.chat.id, "❌ Send a valid number")
        return

    if a == "dep_utr":
        utr = t.replace("UTR:", "").replace("utr:", "").strip().upper()
        if not re.match(r'^[A-Za-z0-9]{10,25}$', utr): send(m.chat.id, "❌ UTR must be 10-25 characters. Try again:"); return
        ss_ = st.get("ss"); amt = st.get("amt", 0)
        if not ss_ or amt <= 0: send(m.chat.id, "❌ Data missing. Start again."); pst(uid); return
        c = db(); cur = c.cursor()
        cur.execute("SELECT id FROM deposits WHERE utr=? AND status IN ('pending','approved')", (utr,))
        if cur.fetchone(): c.close(); send(m.chat.id, "❌ UTR already used."); return
        cur.execute("INSERT INTO deposits(user_id,amount,utr,ss,status) VALUES(?,?,?,?,?)", (uid, amt, utr, ss_, "pending"))
        did = cur.lastrowid; c.commit(); c.close(); pst(uid)
        send(m.chat.id, f"📤 <b>Deposit Submitted</b>\n\n━━━━━━━━━━━━━━━\n\n💰 Amount: ₹{amt}\n📝 UTR: <code>{utr}</code>\n🆔 Request: #{did}\n\n━━━━━━━━━━━━━━━\n\n⏳ <b>Status: Pending Verification</b>\n\nAdmin will verify shortly. Balance added after confirmation.\n\n<i>Contact {CONTACT}</i>\n\n━━━━━━━━━━━━━━━",
            InlineKeyboardMarkup(row_width=1).add(
                InlineKeyboardButton("🔄 𝑪𝒉𝒆𝒄𝒌 𝑺𝒕𝒂𝒕𝒖𝒔", callback_data=f"chkd_{did}", style="primary"),
                InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger")))
        try:
            bot.send_photo(ADMIN_ID, ss_, caption=f"💰 <b>New Deposit</b>\n\n━━━━━━━━━━━━━━━\n\n👤 <code>{uid}</code>\n💰 ₹{amt}\n📝 <code>{utr}</code>\n🆔 #{did}\n\n━━━━━━━━━━━━━━━\n\n<b>Approve or Reject:</b>", parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(row_width=2).add(
                    InlineKeyboardButton("✅ 𝑨𝒑𝒑𝒓𝒐𝒗𝒆", callback_data=f"dap_{did}", style="success"),
                    InlineKeyboardButton("❌ 𝑹𝒆𝒋𝒆𝒄𝒕", callback_data=f"drj_{did}", style="danger")))
        except Exception as e: log.error(f"admin notify: {e}")
        return

    if a == "ai":
        if t.lower() in ("exit","band","stop","quit"): pst(uid); send(m.chat.id, welcome_text(uid), main_menu(uid)); return
        if len(t) < 2: return
        try: bot.send_chat_action(m.chat.id, "typing")
        except: pass
        ans = ai_call(t)
        if ans: send(m.chat.id, f"🤖 <b>Sir Rolex AI</b>\n\n━━━━━━━━━━━━━━━\n\n{esc(ans)}\n\n━━━━━━━━━━━━━━━",
                     InlineKeyboardMarkup().add(InlineKeyboardButton("❌ 𝑪𝒍𝒐𝒔𝒆", callback_data="home", style="danger")))
        else: send(m.chat.id, "❌ AI unavailable.")
        return

    if a == "ticket_subj":
        if len(t) < 2 or len(t) > 200: send(m.chat.id, "❌ 2-200 chars"); return
        st["tks"] = t[:200]; st["a"] = "ticket_msg"; sst(uid, st)
        send(m.chat.id, "📝 <b>Subject Saved</b>\n\n━━━━━━━━━━━━━━━\n\n<b>Now describe your issue:</b>\n\n━━━━━━━━━━━━━━━"); return
    if a == "ticket_msg":
        if len(t) < 2 or len(t) > 2000: send(m.chat.id, "❌ 2-2000 chars"); return
        c = db(); cur = c.cursor()
        cur.execute("INSERT INTO tickets(user_id,subject,message) VALUES(?,?,?)", (uid, st.get("tks","General"), t[:2000]))
        tid = cur.lastrowid; c.commit(); c.close(); pst(uid)
        send(m.chat.id, f"✅ <b>Ticket Created</b>\n\n🎫 Ticket ID: #{tid}\n\nSupport will respond shortly.")
        try: bot.send_message(ADMIN_ID, f"🎫 <b>New Ticket #{tid}</b>\n👤 {uid}\n📝 {esc(st.get('tks',''))}")
        except: pass
        return

    if a == "project_name":
        st["pname"] = t[:100]; st["a"] = "project_price"; sst(uid, st)
        send(m.chat.id, f"✅ Name: <b>{esc(st['pname'])}</b>\n\n<b>Send price:</b>"); return
    if a == "project_price":
        try:
            pr = int(t); st["pprice"] = pr; st["a"] = "project_desc"; sst(uid, st)
            send(m.chat.id, f"✅ Price: ₹{pr}\n\n<b>Send description (or 'skip'):</b>")
        except: send(m.chat.id, "❌ Valid number")
        return
    if a == "project_desc":
        desc = "" if t.lower() == "skip" else t[:500]
        c = db(); cur = c.cursor()
        cur.execute("INSERT INTO projects(name,category,price,description,file_id) VALUES(?,?,?,?,?)", (st.get("pname"), st.get("prjcat","project"), st.get("pprice"), desc, st.get("pfid","")))
        c.commit(); c.close(); pst(uid)
        send(m.chat.id, "✅ Project added"); return

    if a == "faq_q":
        st["fq"] = t[:300]; st["a"] = "faq_a"; sst(uid, st)
        send(m.chat.id, "✅ Question saved\n\n<b>Send answer:</b>"); return
    if a == "faq_a":
        c = db(); cur = c.cursor()
        cur.execute("SELECT COALESCE(MAX(order_num),0)+1 as n FROM faqs")
        nxt = cur.fetchone()["n"]
        cur.execute("INSERT INTO faqs(question,answer,order_num) VALUES(?,?,?)", (st.get("fq"), t[:1000], nxt))
        c.commit(); c.close(); pst(uid)
        send(m.chat.id, "✅ FAQ added"); return

    if not is_admin(uid): return

    if a == "api_u": ss("api_url", t[:500]); pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "api_k": ss("api_key", t[:300]); pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "api_m": ss("master_key", t[:300]); pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "fg_k": ss("fg_key", t[:300]); pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "groq_k": ss("groq", t[:400]); pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "gemini_k": ss("gemini", t[:400]); pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "openai_k": ss("openai", t[:400]); pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "min_dep":
        try: ss("min_dep", int(t)); pst(uid); send(m.chat.id, f"✅ ₹{int(t)}")
        except: send(m.chat.id, "❌ Invalid")
        return
    if a == "res_fee":
        try: ss("reseller_fee", int(t)); pst(uid); send(m.chat.id, f"✅ ₹{int(t)}")
        except: send(m.chat.id, "❌ Invalid")
        return
    if a == "upd_ch": ss("update_channel", t[:500]); pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "tut_link": ss("tutorial_video", t[:500]); pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "sp_link": ss("selling_proof", t[:500]); pst(uid); send(m.chat.id, "✅ Saved"); return

    if a == "add_prod":
        cat = st.get("cat", "general"); c = db(); cur = c.cursor(); n = 0
        for line in t.split("\n"):
            nm = line.strip()[:100]
            if nm: cur.execute("INSERT INTO products(name,category) VALUES(?,?)", (nm, cat)); n += 1
        c.commit(); c.close(); pst(uid)
        send(m.chat.id, f"✅ <b>{n} Products Added</b>"); return

    if a in ("set_pid","set_tut","set_dl","set_demo","set_feat","set_stock","edit_name"):
        pid = st.get("pid"); c = db(); cur = c.cursor()
        try:
            if a == "set_pid": cur.execute("UPDATE products SET api_pid=? WHERE id=?", (t[:100], pid))
            elif a == "set_tut": cur.execute("UPDATE products SET tutorial=? WHERE id=?", (t[:500], pid))
            elif a == "set_dl": cur.execute("UPDATE products SET download=? WHERE id=?", (t[:500], pid))
            elif a == "set_demo": cur.execute("UPDATE products SET demo=? WHERE id=?", (t[:500], pid))
            elif a == "set_feat": cur.execute("UPDATE products SET features=? WHERE id=?", (t[:2000], pid))
            elif a == "set_stock": cur.execute("UPDATE products SET stock=? WHERE id=?", (int(t), pid))
            elif a == "edit_name": cur.execute("UPDATE products SET name=? WHERE id=?", (t[:100], pid))
            c.commit(); c.close(); send(m.chat.id, "✅ Saved")
        except Exception as e: send(m.chat.id, f"❌ {e}")
        pst(uid); return

    if a == "add_plans":
        pid = st.get("pid"); n = 0; c = db(); cur = c.cursor()
        for line in t.split("\n"):
            line = line.strip()
            if not line: continue
            parts = line.rsplit(None, 1)
            if len(parts) != 2: continue
            try:
                pr = int(parts[1]); dur = parts[0].strip()[:50]
                cur.execute("INSERT INTO plans(product_id,duration,price) VALUES(?,?,?)", (pid, dur, pr)); n += 1
            except: continue
        c.commit(); c.close(); pst(uid)
        send(m.chat.id, f"✅ {n} Plans Added"); return

    if a == "add_bal":
        p = t.split()
        if len(p) != 2: send(m.chat.id, "❌ user_id amount"); return
        try:
            tid = int(p[0]); amt = int(p[1])
            c = db(); cur = c.cursor()
            cur.execute("UPDATE users SET balance=balance+? WHERE id=?", (amt, tid))
            if cur.rowcount == 0: cur.execute("INSERT INTO users(id,balance) VALUES(?,?)", (tid, amt))
            cur.execute("INSERT INTO txs(user_id,amount,type) VALUES(?,?,'add_money')", (tid, amt))
            c.commit(); c.close()
            send(m.chat.id, f"✅ ₹{amt} → {tid}")
            try: send(tid, f"💰 ₹{amt} added to balance")
            except: pass
        except: send(m.chat.id, "❌ Invalid")
        pst(uid); return

    if a == "bc":
        c = db(); cur = c.cursor()
        cur.execute("SELECT id FROM users WHERE banned=0")
        ids = [r["id"] for r in cur.fetchall()]; c.close()
        send(m.chat.id, f"📢 Sending to {len(ids)}...")
        n = 0
        for i in ids:
            try: send(i, f"📢 <b>Announcement</b>\n\n━━━━━━━━━━━━━━━\n\n{esc(t)}\n\n━━━━━━━━━━━━━━━"); n += 1
            except: pass
            time.sleep(0.05)
        pst(uid); send(m.chat.id, f"✅ Sent to {n}"); return

    if a == "set_welcome":
        if t.lower() == "reset": ss("welcome", None)
        else: ss("welcome", t[:3000])
        pst(uid); send(m.chat.id, "✅ Saved"); return
    if a == "set_badge": ss("badge", t[:100]); pst(uid); send(m.chat.id, "✅ Saved"); return

    if a == "menu_emo":
        st["me_e"] = t[:5]; st["a"] = "menu_label"; sst(uid, st)
        send(m.chat.id, "📝 Step 2/4: Send label"); return
    if a == "menu_label":
        st["me_l"] = t[:40]; st["a"] = "menu_val"; sst(uid, st)
        send(m.chat.id, "🔗 Step 3/4: Send value"); return
    if a == "menu_val":
        st["me_v"] = t[:500]; st["a"] = "menu_type_ask"; sst(uid, st)
        kb = InlineKeyboardMarkup(row_width=2)
        kb.add(InlineKeyboardButton("📝 𝑻𝒆𝒙𝒕", callback_data="mty_text", style="primary"),
               InlineKeyboardButton("🔗 𝑼𝑹𝑳", callback_data="mty_url", style="success"))
        send(m.chat.id, "🎯 Step 4/4: Choose type:", kb); return
    if a == "menu_edit_emoji":
        idx = st.get("idx"); menu = get_menu()
        if idx < len(menu): menu[idx]["e"] = t[:5]; set_menu(menu)
        pst(uid); send(m.chat.id, "✅ Updated"); return
    if a == "menu_edit_label":
        idx = st.get("idx"); menu = get_menu()
        if idx < len(menu): menu[idx]["l"] = t[:40]; set_menu(menu)
        pst(uid); send(m.chat.id, "✅ Updated"); return

    if a == "rej_reason":
        did = st.get("did"); reason = t if t.lower() != "skip" else "Verification failed"
        c = db(); cur = c.cursor()
        cur.execute("SELECT user_id,status FROM deposits WHERE id=?", (did,))
        dep = cur.fetchone()
        if dep and dep["status"] == "pending":
            cur.execute("UPDATE deposits SET status='rejected',reason=? WHERE id=?", (reason, did))
            c.commit()
            try: send(dep["user_id"], f"❌ <b>Deposit Rejected</b>\n\nReason: {esc(reason)}")
            except: pass
        c.close(); pst(uid); send(m.chat.id, "✅ Rejected"); return

    if a == "cp_code":
        code = t.upper().replace(" ", "")
        if not re.match(r'^[A-Z0-9]{3,20}$', code): send(m.chat.id, "❌ 3-20 A-Z 0-9"); return
        c = db(); cur = c.cursor()
        cur.execute("SELECT id FROM coupons WHERE code=?", (code,))
        if cur.fetchone(): c.close(); send(m.chat.id, "❌ Exists"); return
        c.close()
        st["cp_c"] = code; st["a"] = "cp_disc"; sst(uid, st)
        send(m.chat.id, f"✅ {code}\n\nDiscount % (1-90):"); return
    if a == "cp_disc":
        try:
            d = int(t)
            if d < 1 or d > 90: raise
            st["cp_d"] = d; st["a"] = "cp_max"; sst(uid, st)
            send(m.chat.id, f"✅ {d}%\n\nMax uses:")
        except: send(m.chat.id, "❌ 1-90")
        return
    if a == "cp_max":
        try:
            mx = int(t)
            if mx < 1: raise
            c = db(); cur = c.cursor()
            cur.execute("INSERT INTO coupons(code,discount,max_uses) VALUES(?,?,?)", (st.get("cp_c"), st.get("cp_d"), mx))
            c.commit(); c.close(); pst(uid); send(m.chat.id, "✅ Coupon created")
        except: send(m.chat.id, "❌ Invalid")
        return

    if a == "ticket_reply":
        tid = st.get("tid"); c = db(); cur = c.cursor()
        cur.execute("SELECT user_id FROM tickets WHERE id=?", (tid,))
        tk = cur.fetchone()
        if tk:
            cur.execute("UPDATE tickets SET reply=?,status='closed' WHERE id=?", (t[:2000], tid))
            c.commit()
            try: send(tk["user_id"], f"💬 <b>Support Reply</b>\n\n{esc(t)}")
            except: pass
        c.close(); pst(uid); send(m.chat.id, "✅ Sent"); return

@bot.callback_query_handler(func=lambda c: True)
def on_cb(call):
    uid = call.from_user.id
    d = call.data
    st = gst(uid)
    if is_banned(uid): return
    try:
        if d == "home": nav(call, welcome_text(uid), main_menu(uid)); return

        # SHOP
        if d == "shop":
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("🤖 𝑨𝒏𝒅𝒓𝒐𝒊𝒅 𝑹𝒐𝒐𝒕", callback_data="cat_root", style="primary"))
            m.add(InlineKeyboardButton("📱 𝑨𝒏𝒅𝒓𝒐𝒊𝒅 𝑵𝒐𝒏-𝑹𝒐𝒐𝒕", callback_data="cat_nonroot", style="primary"))
            m.add(InlineKeyboardButton("🍎 𝒊𝑷𝒉𝒐𝒏𝒆", callback_data="cat_iphone", style="primary"))
            m.add(InlineKeyboardButton("🛠️ 𝑻𝒐𝒐𝒍𝒔", callback_data="cat_tools", style="primary"))
            m.add(InlineKeyboardButton("📚 𝑶𝒕𝒉𝒆𝒓", callback_data="cat_general", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
            nav(call, "🛍️ <b>Select Category</b>\n\n━━━━━━━━━━━━━━━\n\nChoose a category to browse.\n\n━━━━━━━━━━━━━━━", m); return

        if d.startswith("cat_"):
            cat = d.replace("cat_", "")
            c = db(); cur = c.cursor()
            cur.execute("SELECT id,name,status FROM products WHERE category=?", (cat,))
            ps = cur.fetchall(); c.close()
            if not ps:
                nav(call, f"😔 <b>No Products</b>\n\nNo {cat.upper()} products available.",
                    InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="shop", style="danger"))); return
            m = InlineKeyboardMarkup(row_width=1)
            for p in ps:
                s = "🔧" if p["status"] == "maintenance" else "🔑"
                m.add(InlineKeyboardButton(f"{s} {p['name']}", callback_data=f"p_{p['id']}", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="shop", style="danger"))
            cat_names = {"root":"Android Root","nonroot":"Android Non-Root","iphone":"iPhone","tools":"Tools","general":"Other"}
            nav(call, f"📦 <b>{cat_names.get(cat, cat.upper())}</b>\n\n━━━━━━━━━━━━━━━", m); return

        if d.startswith("p_") and len(d.split("_")) == 2:
            try: pid = int(d.split("_")[1])
            except: return
            c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM products WHERE id=?", (pid,))
            p = cur.fetchone()
            cur.execute("SELECT id,duration,price,reseller_price FROM plans WHERE product_id=?", (pid,))
            plans = cur.fetchall(); c.close()
            if not p: return
            if p["status"] == "maintenance":
                nav(call, f"🔧 <b>Maintenance</b>\n\n{esc(p['name'])}",
                    InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data=f"cat_{p['category']}", style="danger"))); return
            sv = p["stock"] if p["stock"] is not None else -1
            if sv == 0:
                nav(call, f"❌ <b>Out of Stock</b>\n\n{esc(p['name'])}",
                    InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data=f"cat_{p['category']}", style="danger"))); return
            t = f"🔑 <b>{esc(p['name'])}</b>\n\n━━━━━━━━━━━━━━━\n\n"
            if sv > 0: t += f"⚡ Stock: {sv} available\n\n"
            if p["features"]: t += f"<b>Features:</b>\n<blockquote>{esc(p['features'])}</blockquote>\n\n"
            t += "━━━━━━━━━━━━━━━\n\n<b>Select Duration:</b>"
            m = InlineKeyboardMarkup(row_width=1)
            rsl = is_res(uid)
            for pl in plans:
                if rsl and pl["reseller_price"]:
                    m.add(InlineKeyboardButton(f"⭐ {pl['duration']} — ₹{pl['reseller_price']}", callback_data=f"b_{pid}_{pl['id']}", style="success"))
                else:
                    m.add(InlineKeyboardButton(f"🔑 {pl['duration']} — ₹{pl['price']}", callback_data=f"b_{pid}_{pl['id']}", style="success"))
            if p["tutorial"]: m.add(InlineKeyboardButton("📺 𝑾𝒂𝒕𝒄𝒉 𝑻𝒖𝒕𝒐𝒓𝒊𝒂𝒍", url=p["tutorial"], style="primary"))
            if p["demo"]: m.add(InlineKeyboardButton("🎬 𝑾𝒂𝒕𝒄𝒉 𝑫𝒆𝒎𝒐", url=p["demo"], style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data=f"cat_{p['category']}", style="danger"))
            nav(call, t, m); return

        if d.startswith("b_"):
            parts = d.split("_"); pid, plid = int(parts[1]), int(parts[2])
            c = db(); cur = c.cursor()
            cur.execute("SELECT p.name, pl.duration, pl.price, pl.reseller_price FROM plans pl JOIN products p ON p.id=pl.product_id WHERE pl.id=?", (plid,))
            r = cur.fetchone()
            cur.execute("SELECT balance FROM users WHERE id=?", (uid,))
            u = cur.fetchone(); c.close()
            if not r or not u: return
            price = r["reseller_price"] if is_res(uid) and r["reseller_price"] else r["price"]
            bal = u["balance"] or 0; short = price - bal
            t = f"🛒 <b>Order Confirmation</b>\n\n━━━━━━━━━━━━━━━\n\n📦 <b>{esc(r['name'])}</b>\n⏰ {esc(r['duration'])}\n\n━━━━━━━━━━━━━━━\n\n💰 Price: ₹{price}\n💵 Balance: ₹{bal}"
            if short > 0: t += f"\n\n━━━━━━━━━━━━━━━\n\n⚠️ Need ₹{short} more"
            else: t += "\n\n━━━━━━━━━━━━━━━\n\n✅ Ready to purchase"
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("✅ 𝑪𝒐𝒏𝒇𝒊𝒓𝒎 𝑶𝒓𝒅𝒆𝒓", callback_data=f"cf_{pid}_{plid}", style="success"))
            if short > 0: m.add(InlineKeyboardButton("💰 𝑨𝒅𝒅 𝑩𝒂𝒍𝒂𝒏𝒄𝒆", callback_data="add_bal", style="success"))
            m.add(InlineKeyboardButton("❌ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="home", style="danger"))
            nav(call, t, m); return

        if d.startswith("cf_"):
            parts = d.split("_"); pid, plid = int(parts[1]), int(parts[2])
            c = db(); cur = c.cursor()
            cur.execute("SELECT p.*, pl.duration, pl.price, pl.reseller_price FROM plans pl JOIN products p ON p.id=pl.product_id WHERE pl.id=?", (plid,))
            r = cur.fetchone()
            cur.execute("SELECT balance FROM users WHERE id=?", (uid,))
            u = cur.fetchone()
            if not r or not u: c.close(); return
            price = r["reseller_price"] if is_res(uid) and r["reseller_price"] else r["price"]
            if u["balance"] < price: c.close(); bot.answer_callback_query(call.id, f"❌ Need ₹{price}", show_alert=True); return
            sv = r["stock"] if r["stock"] is not None else -1
            if sv == 0: c.close(); bot.answer_callback_query(call.id, "❌ Out of stock", show_alert=True); return
            cur.execute("UPDATE users SET balance=balance-? WHERE id=? AND balance>=?", (price, uid, price))
            if cur.rowcount != 1: c.close(); return
            c.commit(); c.close()
            bot.answer_callback_query(call.id, "⏳ Processing...")
            api_pid = r["api_pid"]; api_url = r["api_url"] or gs("api_url",""); api_key = r["api_key"] or gs("api_key",""); master = r["master_key"] or gs("master_key","")
            key = None; err = None
            if api_url and api_pid:
                try:
                    resp = requests.post(api_url, data={'api_key':api_key,'action':'buy','product_id':str(api_pid),'duration':r["duration"]}, headers={'x-master-key':master,'User-Agent':'Mozilla/5.0'}, timeout=25).text.strip()
                    if resp.startswith("{"):
                        try:
                            j = json.loads(resp)
                            if j.get("status","").lower() == "success": key = j.get("key") or j.get("license_key")
                            else: err = j.get("message","API error")
                        except: pass
                    if not key and re.match(r'^[A-Z0-9\-]{8,60}$', resp): key = resp
                    if not key and not err: err = resp[:100]
                except Exception as e: err = str(e)[:100]
            if key:
                c = db(); cur = c.cursor()
                cur.execute("UPDATE users SET total_orders=total_orders+1,total_spent=total_spent+? WHERE id=?", (price, uid))
                cur.execute("INSERT INTO txs(user_id,amount,type,details,key,product,duration) VALUES(?,?,'purchase','api',?,?,?)", (uid, price, key, r["name"], r["duration"]))
                if sv > 0: cur.execute("UPDATE products SET stock=stock-1 WHERE id=? AND stock>0", (pid,))
                c.commit(); c.close()
                cap = f"✅ <b>Order Complete</b>\n\n━━━━━━━━━━━━━━━\n\n📦 <b>{esc(r['name'])}</b>\n⏰ {esc(r['duration'])}\n💰 ₹{price}\n\n━━━━━━━━━━━━━━━\n\n🔑 <b>Your License Key</b>\n\n<i>Tap the key to copy</i>\n\n<code>{esc(key)}</code>\n\n━━━━━━━━━━━━━━━\n\n<i>Any issues? Contact {CONTACT}</i>"
                m = InlineKeyboardMarkup(row_width=1)
                if r["download"]: m.add(InlineKeyboardButton("📥 𝑫𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝑨𝑷𝑲", url=r["download"], style="primary"))
                if r["tutorial"]: m.add(InlineKeyboardButton("📺 𝑺𝒆𝒕𝒖𝒑 𝑽𝒊𝒅𝒆𝒐", url=r["tutorial"], style="primary"))
                m.add(InlineKeyboardButton(f"💬 𝑪𝒐𝒏𝒕𝒂𝒄𝒕", url=f"https://t.me/{CONTACT.replace('@','')}", style="success"))
                m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
                try: bot.send_photo(call.message.chat.id, SUCCESS_IMG, caption=cap, parse_mode="HTML", reply_markup=m)
                except: send(call.message.chat.id, cap, m)
            else:
                c = db(); cur = c.cursor()
                cur.execute("INSERT INTO txs(user_id,amount,type,details,product,duration) VALUES(?,?,'pending','manual',?,?)", (uid, price, r["name"], r["duration"]))
                tid = cur.lastrowid; c.commit(); c.close()
                send(call.message.chat.id, f"⏳ <b>Order Placed</b>\n\n📦 {esc(r['name'])}\n⏰ {esc(r['duration'])}\n💰 ₹{price}\n\nAdmin will deliver shortly.\n\n<b>Contact:</b> {CONTACT}",
                    InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton(f"💬 {CONTACT}", url=f"https://t.me/{CONTACT.replace('@','')}", style="success"), InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger")))
                try: bot.send_message(ADMIN_ID, f"🔔 Manual Order\n👤 {uid}\n📦 {r['name']}\n💰 ₹{price}")
                except: pass
            return

        if d == "profile":
            c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM users WHERE id=?", (uid,))
            u = cur.fetchone(); c.close()
            if not u: return
            t = f"👤 <b>My Profile</b>\n\n━━━━━━━━━━━━━━━\n\n🆔 User ID: <code>{uid}</code>\n👑 Account: {'Reseller' if u['is_reseller'] else 'Member'}\n\n━━━━━━━━━━━━━━━\n\n💰 Balance: ₹{u['balance'] or 0}\n📦 Orders: {u['total_orders'] or 0}\n💸 Spent: ₹{u['total_spent'] or 0}\n\n━━━━━━━━━━━━━━━\n\n📅 Joined: {u['joined'][:10] if u['joined'] else 'N/A'}"
            nav(call, t, InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return

        if d == "add_bal":
            upi = gs("upi","laskarsumona85@okicici"); md = int(gs("min_dep", 10))
            t = f"💰 <b>Add Balance</b>\n\n━━━━━━━━━━━━━━━\n\n📱 UPI ID:\n<code>{esc(upi)}</code>\n\n━━━━━━━━━━━━━━━\n\n<b>Steps:</b>\n\n1. Pay to UPI ID above\n2. Take screenshot\n3. Send screenshot\n4. Enter amount\n5. Send UTR\n\n━━━━━━━━━━━━━━━\n\n💰 Minimum: ₹{md}\n⏳ Time: 5-30 min"
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("📸 𝑺𝒆𝒏𝒅 𝑷𝒓𝒐𝒐𝒇", callback_data="dep_proof", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
            qr = f"https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=upi%3A%2F%2Fpay%3Fpa%3D{upi.replace('@','%40')}%26pn%3D{BRAND.replace(' ','%20')}%26cu%3DINR"
            try:
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_photo(call.message.chat.id, qr, caption=t, parse_mode="HTML", reply_markup=m)
            except: nav(call, t, m)
            return

        if d == "dep_proof":
            st["a"] = "dep_ss"; sst(uid, st)
            nav(call, "📸 <b>Send Screenshot</b>\n\n━━━━━━━━━━━━━━━\n\n<b>Step 1 of 3</b>\n\nSend payment screenshot.\n\n━━━━━━━━━━━━━━━",
                InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="home", style="danger"))); return

        if d.startswith("chkd_"):
            did = int(d.split("_")[1])
            c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM deposits WHERE id=? AND user_id=?", (did, uid))
            dep = cur.fetchone(); c.close()
            if not dep: bot.answer_callback_query(call.id, "❌", show_alert=True); return
            if dep["status"] == "approved": nav(call, f"✅ <b>Approved</b>\n\n₹{dep['amount']} added", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger")))
            elif dep["status"] == "rejected": nav(call, f"❌ <b>Rejected</b>\n\n{esc(dep['reason'] or 'Contact support')}", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger")))
            else: nav(call, "⏳ <b>Pending</b>\n\nAdmin will verify shortly.", InlineKeyboardMarkup().add(InlineKeyboardButton("🔄 𝑹𝒆𝒇𝒓𝒆𝒔𝒉", callback_data=f"chkd_{did}", style="primary"), InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger")))
            return

        if d == "orders":
            c = db(); cur = c.cursor()
            cur.execute("SELECT key,product,duration,amount FROM txs WHERE user_id=? AND type='purchase' AND key IS NOT NULL ORDER BY id DESC LIMIT 10", (uid,))
            rows = cur.fetchall(); c.close()
            if not rows:
                nav(call, "📜 <b>All History</b>\n\n━━━━━━━━━━━━━━━\n\nNo orders yet.\n\n━━━━━━━━━━━━━━━",
                    InlineKeyboardMarkup().add(InlineKeyboardButton("🛍️ 𝑺𝒉𝒐𝒑", callback_data="shop", style="success"), InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return
            t = "📜 <b>All History</b>\n\n━━━━━━━━━━━━━━━\n\n"
            for r in rows: t += f"📦 <b>{esc(r['product'])}</b>\n⏰ {esc(r['duration'])}\n💰 ₹{r['amount']}\n🔑 <code>{esc(r['key'])}</code>\n\n━━━━━━━━━━━━━━━\n\n"
            nav(call, t, InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return

        if d == "tutorial":
            vid = gs("tutorial_video", "")
            m = InlineKeyboardMarkup(row_width=1)
            if vid: m.add(InlineKeyboardButton("▶️ 𝑾𝒂𝒕𝒄𝒉 𝑽𝒊𝒅𝒆𝒐", url=vid, style="primary"))
            m.add(InlineKeyboardButton("📞 𝑺𝒖𝒑𝒑𝒐𝒓𝒕", callback_data="support", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
            nav(call, "📖 <b>How to Use</b>\n\n━━━━━━━━━━━━━━━\n\n1. Start bot\n2. Add balance\n3. Shop Key\n4. Select product\n5. Confirm order\n6. Copy key\n7. Use in game\n\n━━━━━━━━━━━━━━━", m); return

        if d == "selling_proof":
            link = gs("selling_proof", "https://t.me/ETROLEX")
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("📸 𝑶𝒑𝒆𝒏 𝑪𝒉𝒂𝒏𝒏𝒆𝒍", url=link, style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
            nav(call, "📸 <b>Selling Proof</b>\n\n━━━━━━━━━━━━━━━\n\nSee real customer reviews and payment proofs.\n\n━━━━━━━━━━━━━━━", m); return

        if d == "support":
            sn = gs("support_name","Sir Rolex Support"); su = gs("support_url",f"https://t.me/{CONTACT.replace('@','')}")
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton(f"💬 𝑪𝒉𝒂𝒕 𝒘𝒊𝒕𝒉 𝑺𝒖𝒑𝒑𝒐𝒓𝒕", url=su, style="primary"))
            m.add(InlineKeyboardButton("🎫 𝑪𝒓𝒆𝒂𝒕𝒆 𝑻𝒊𝒄𝒌𝒆𝒕", callback_data="new_tk", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
            nav(call, f"📞 <b>Support Center</b>\n\n━━━━━━━━━━━━━━━\n\n👨‍💼 <b>{esc(sn)}</b>\n\n━━━━━━━━━━━━━━━", m); return

        if d == "new_tk":
            st["a"] = "ticket_subj"; sst(uid, st)
            nav(call, "🎫 <b>Create Ticket</b>\n\n━━━━━━━━━━━━━━━\n\n<b>Step 1 of 2</b>\n\nSend subject.\n<i>Example: Payment not credited</i>\n\n━━━━━━━━━━━━━━━",
                InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="home", style="danger"))); return

        if d == "faq":
            c = db(); cur = c.cursor()
            cur.execute("SELECT id,question FROM faqs ORDER BY order_num ASC, id ASC")
            faqs = cur.fetchall(); c.close()
            if not faqs: nav(call, "❓ <b>FAQ</b>\n\nNo FAQs available.", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return
            m = InlineKeyboardMarkup(row_width=1)
            for f in faqs: m.add(InlineKeyboardButton(f"❓ {f['question'][:55]}", callback_data=f"faq_{f['id']}", style="primary"))
            m.add(InlineKeyboardButton("📞 𝑺𝒕𝒊𝒍𝒍 𝒏𝒆𝒆𝒅 𝒉𝒆𝒍𝒑?", callback_data="support", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
            nav(call, "❓ <b>Frequently Asked Questions</b>\n\n━━━━━━━━━━━━━━━\n\nTap a question.\n\n━━━━━━━━━━━━━━━", m); return

        if d.startswith("faq_"):
            try: fid = int(d.split("_")[1])
            except: return
            c = db(); cur = c.cursor()
            cur.execute("SELECT question,answer FROM faqs WHERE id=?", (fid,))
            f = cur.fetchone(); c.close()
            if not f: return
            nav(call, f"❓ <b>{esc(f['question'])}</b>\n\n━━━━━━━━━━━━━━━\n\n{esc(f['answer'])}\n\n━━━━━━━━━━━━━━━",
                InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌 𝒕𝒐 𝑭𝑨𝑸", callback_data="faq", style="primary"), InlineKeyboardButton("📞 𝑺𝒖𝒑𝒑𝒐𝒓𝒕", callback_data="support", style="success"))); return

        if d == "referral":
            try: bn = bot.get_me().username
            except: bn = "SirRolexBot"
            link = f"https://t.me/{bn}?start=ref_{uid}"
            nav(call, f"🎁 <b>Referral Program</b>\n\n━━━━━━━━━━━━━━━\n\nYour link:\n<code>{link}</code>\n\n━━━━━━━━━━━━━━━\n\n<i>Earn bonus when friends purchase!</i>\n\n━━━━━━━━━━━━━━━",
                InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton("📤 𝑺𝒉𝒂𝒓𝒆 𝑳𝒊𝒏𝒌", url=f"https://t.me/share/url?url={link}", style="success"), InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return

        if d == "ai":
            st["a"] = "ai"; sst(uid, st)
            nav(call, "🤖 <b>Sir Rolex AI</b>\n\n━━━━━━━━━━━━━━━\n\nAsk me anything!\n\nI can help with products, payments, account.\n\n━━━━━━━━━━━━━━━\n\n<i>Type \"exit\" to close</i>\n\n━━━━━━━━━━━━━━━",
                InlineKeyboardMarkup().add(InlineKeyboardButton("❌ 𝑪𝒍𝒐𝒔𝒆", callback_data="home", style="danger"))); return

        if d == "projects":
            c = db(); cur = c.cursor()
            cur.execute("SELECT id,name,price FROM projects WHERE category='project' ORDER BY id DESC")
            rows = cur.fetchall(); c.close()
            if not rows: nav(call, "📁 <b>Buy Project</b>\n\nNo projects available.", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return
            m = InlineKeyboardMarkup(row_width=1)
            for r in rows: m.add(InlineKeyboardButton(f"📁 {r['name']} — ₹{r['price']}", callback_data=f"prj_{r['id']}", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
            nav(call, "📁 <b>Buy Project</b>\n\n━━━━━━━━━━━━━━━", m); return

        if d == "configs":
            c = db(); cur = c.cursor()
            cur.execute("SELECT id,name,price FROM projects WHERE category='config' ORDER BY id DESC")
            rows = cur.fetchall(); c.close()
            if not rows: nav(call, "⚙️ <b>Buy Config</b>\n\nNo configs available.", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return
            m = InlineKeyboardMarkup(row_width=1)
            for r in rows: m.add(InlineKeyboardButton(f"⚙️ {r['name']} — ₹{r['price']}", callback_data=f"prj_{r['id']}", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
            nav(call, "⚙️ <b>Buy Config</b>\n\n━━━━━━━━━━━━━━━", m); return

        if d.startswith("prj_"):
            pid = int(d.split("_")[1])
            c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM projects WHERE id=?", (pid,))
            p = cur.fetchone()
            cur.execute("SELECT balance FROM users WHERE id=?", (uid,))
            u = cur.fetchone(); c.close()
            if not p or not u: return
            bal = u["balance"] or 0; short = p["price"] - bal
            t = f"📦 <b>{esc(p['name'])}</b>\n\n━━━━━━━━━━━━━━━\n\n{esc(p['description'] or 'No description')}\n\n━━━━━━━━━━━━━━━\n\n💰 Price: ₹{p['price']}\n💵 Balance: ₹{bal}"
            if short > 0: t += f"\n\n⚠️ Need ₹{short} more"
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton(f"✅ 𝑩𝒖𝒚 — ₹{p['price']}", callback_data=f"prjbuy_{pid}", style="success"))
            if short > 0: m.add(InlineKeyboardButton("💰 𝑨𝒅𝒅 𝑩𝒂𝒍𝒂𝒏𝒄𝒆", callback_data="add_bal", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))
            nav(call, t, m); return

        if d.startswith("prjbuy_"):
            pid = int(d.split("_")[1])
            c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM projects WHERE id=?", (pid,))
            p = cur.fetchone()
            cur.execute("SELECT balance FROM users WHERE id=?", (uid,))
            u = cur.fetchone()
            if not p or not u: c.close(); return
            if u["balance"] < p["price"]: c.close(); bot.answer_callback_query(call.id, "❌ Insufficient", show_alert=True); return
            cur.execute("UPDATE users SET balance=balance-? WHERE id=?", (p["price"], uid))
            cur.execute("INSERT INTO txs(user_id,amount,type,details,product) VALUES(?,?,'purchase','project',?)", (uid, p["price"], p["name"]))
            c.commit(); c.close()
            try:
                if p["file_id"]: bot.send_document(call.message.chat.id, p["file_id"], caption=f"✅ <b>{esc(p['name'])}</b>", parse_mode="HTML")
                else: send(call.message.chat.id, f"✅ <b>{esc(p['name'])}</b>")
            except: send(call.message.chat.id, f"✅ {esc(p['name'])}")
            return

        if d == "reseller":
            if is_res(uid): nav(call, "✦ <b>You are a Reseller</b>", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return
            fee = int(gs("reseller_fee", 399))
            nav(call, f"🤝 <b>Become Reseller</b>\n\n━━━━━━━━━━━━━━━\n\n<b>Benefits:</b>\n\n▸ Special prices\n▸ Higher profits\n▸ Priority support\n\n━━━━━━━━━━━━━━━\n\n💰 Fee: ₹{fee}\n\n━━━━━━━━━━━━━━━",
                InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton("🤝 𝑺𝒆𝒏𝒅 𝑹𝒆𝒒𝒖𝒆𝒔𝒕", callback_data="resreq", style="success"), InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return

        if d == "resreq":
            try:
                bot.send_message(ADMIN_ID, f"🤝 Reseller Request\n👤 {uid}\n@{call.from_user.username or 'N/A'}",
                    reply_markup=InlineKeyboardMarkup(row_width=2).add(
                        InlineKeyboardButton("✅ 𝑨𝒑𝒑𝒓𝒐𝒗𝒆", callback_data=f"resap_{uid}", style="success"),
                        InlineKeyboardButton("❌ 𝑹𝒆𝒋𝒆𝒄𝒕", callback_data=f"resrj_{uid}", style="danger")))
            except: pass
            bot.answer_callback_query(call.id, "✅ Request sent!", show_alert=True)
            send(call.message.chat.id, "✅ <b>Request sent!</b>\n\nAdmin will approve soon.")
            return

        if d == "reseller_panel":
            nav(call, "✦ <b>Reseller Panel</b>\n\nYou have reseller benefits!",
                InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return

        if d.startswith("resap_"):
            tid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("UPDATE users SET is_reseller=1 WHERE id=?", (tid,))
            c.commit(); c.close()
            try: send(tid, "🎉 <b>You are now a Reseller!</b>")
            except: pass
            bot.answer_callback_query(call.id, "✅ Approved", show_alert=True); return

        if d.startswith("resrj_"):
            tid = int(d.split("_")[1])
            try: send(tid, "❌ Reseller request rejected.")
            except: pass
            bot.answer_callback_query(call.id, "✅ Rejected", show_alert=True); return

        if d == "spin":
            if is_res(uid): nav(call, "🎮 <b>Lucky Spin</b>\n\nResellers can't play.", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return
            nav(call, "🎮 <b>Lucky Spin</b>\n\n━━━━━━━━━━━━━━━\n\nWin ₹1 - ₹5!\n\n━━━━━━━━━━━━━━━",
                InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton("🎮 𝑺𝒑𝒊𝒏 𝑵𝒐𝒘", callback_data="spin_go", style="success"), InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return

        if d == "spin_go":
            amt = random.randint(1, 5)
            c = db(); cur = c.cursor()
            cur.execute("UPDATE users SET balance=balance+? WHERE id=?", (amt, uid))
            cur.execute("INSERT INTO txs(user_id,amount,type,details) VALUES(?,?,'spin','spin')", (uid, amt))
            c.commit(); c.close()
            send(call.message.chat.id, f"🎉 <b>You won ₹{amt}!</b>\n\nBalance added.", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger")))
            return

        # ADMIN
        if d == "admin":
            if not is_admin(uid): bot.answer_callback_query(call.id, "⛔", show_alert=True); return
            nav(call, ahead(), admin_menu(uid)); return

        if d == "ap":
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("➕ 𝑨𝒅𝒅 𝑷𝒓𝒐𝒅𝒖𝒄𝒕", callback_data="ap_add", style="success"))
            m.add(InlineKeyboardButton("📋 𝑴𝒂𝒏𝒂𝒈𝒆", callback_data="ap_manage", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, "📦 <b>Products Manager</b>", m); return

        if d == "ap_add":
            m = InlineKeyboardMarkup(row_width=1)
            for cat, label in [("root","🤖 𝑨𝒏𝒅𝒓𝒐𝒊𝒅 𝑹𝒐𝒐𝒕"),("nonroot","📱 𝑵𝒐𝒏-𝑹𝒐𝒐𝒕"),("iphone","🍎 𝒊𝑷𝒉𝒐𝒏𝒆"),("tools","🛠️ 𝑻𝒐𝒐𝒍𝒔"),("general","📚 𝑶𝒕𝒉𝒆𝒓")]:
                m.add(InlineKeyboardButton(label, callback_data=f"apc_{cat}", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="ap", style="danger"))
            nav(call, "➕ <b>Add Product</b>\n\nChoose category:", m); return

        if d.startswith("apc_"):
            cat = d.replace("apc_", "")
            st["a"] = "add_prod"; st["cat"] = cat; sst(uid, st)
            nav(call, f"📝 <b>Add {cat.upper()} Products</b>\n\nSend names, one per line.",
                InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="ap", style="danger"))); return

        if d == "ap_manage":
            m = InlineKeyboardMarkup(row_width=1)
            for cat, label in [("root","🤖 𝑨𝒏𝒅𝒓𝒐𝒊𝒅 𝑹𝒐𝒐𝒕"),("nonroot","📱 𝑵𝒐𝒏-𝑹𝒐𝒐𝒕"),("iphone","🍎 𝒊𝑷𝒉𝒐𝒏𝒆"),("tools","🛠️ 𝑻𝒐𝒐𝒍𝒔"),("general","📚 𝑶𝒕𝒉𝒆𝒓")]:
                m.add(InlineKeyboardButton(label, callback_data=f"ampc_{cat}", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="ap", style="danger"))
            nav(call, "📋 <b>Manage Products</b>\n\nChoose category:", m); return

        if d.startswith("ampc_"):
            cat = d.replace("ampc_", "")
            c = db(); cur = c.cursor()
            cur.execute("SELECT id,name,status,api_pid FROM products WHERE category=? ORDER BY id DESC", (cat,))
            ps = cur.fetchall(); c.close()
            if not ps: nav(call, f"❌ No {cat.upper()} products", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="ap_manage", style="danger"))); return
            m = InlineKeyboardMarkup(row_width=1)
            for p in ps:
                s = "🔧" if p["status"]=="maintenance" else ("✅" if p["api_pid"] else "⚠️")
                m.add(InlineKeyboardButton(f"{s} {p['name']}", callback_data=f"pedit_{p['id']}", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="ap_manage", style="danger"))
            nav(call, f"📋 <b>{cat.upper()}</b>\n\n✅ API set | ⚠️ No API | 🔧 Maintenance", m); return

        if d.startswith("pedit_"):
            pid = int(d.split("_")[1])
            c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM products WHERE id=?", (pid,))
            p = cur.fetchone()
            cur.execute("SELECT COUNT(*) as n FROM plans WHERE product_id=?", (pid,))
            pc = cur.fetchone()["n"]; c.close()
            if not p: return
            t = f"📦 <b>{esc(p['name'])}</b>\n\n━━━━━━━━━━━━━━━\n🔗 PID: <code>{esc(p['api_pid'] or 'Not Set')}</code>\n📅 Plans: {pc}\n📦 Stock: {p['stock']}\n📊 {p['status'].upper()}\n━━━━━━━━━━━━━━━"
            m = InlineKeyboardMarkup(row_width=2)
            m.add(InlineKeyboardButton("✏️ 𝑵𝒂𝒎𝒆", callback_data=f"pna_{pid}", style="primary"), InlineKeyboardButton("🔗 𝑷𝑰𝑫", callback_data=f"ppi_{pid}", style="success"))
            m.add(InlineKeyboardButton("📅 𝑷𝒍𝒂𝒏𝒔", callback_data=f"ppl_{pid}", style="success"), InlineKeyboardButton("📺 𝑻𝒖𝒕𝒐𝒓𝒊𝒂𝒍", callback_data=f"ptu_{pid}", style="primary"))
            m.add(InlineKeyboardButton("📥 𝑫𝒐𝒘𝒏𝒍𝒐𝒂𝒅", callback_data=f"pdl_{pid}", style="primary"), InlineKeyboardButton("🎬 𝑫𝒆𝒎𝒐", callback_data=f"pdm_{pid}", style="primary"))
            m.add(InlineKeyboardButton("📝 𝑭𝒆𝒂𝒕𝒖𝒓𝒆𝒔", callback_data=f"pft_{pid}", style="primary"), InlineKeyboardButton("📦 𝑺𝒕𝒐𝒄𝒌", callback_data=f"pst_{pid}", style="success"))
            m.add(InlineKeyboardButton("🔧 𝑴𝒂𝒊𝒏𝒕𝒆𝒏𝒂𝒏𝒄𝒆", callback_data=f"ptg_{pid}", style="danger"), InlineKeyboardButton("🗑️ 𝑫𝒆𝒍𝒆𝒕𝒆", callback_data=f"pde_{pid}", style="danger"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data=f"ampc_{p['category']}", style="danger"))
            nav(call, t, m); return

        for pr, act in [("pna_","edit_name"),("ppi_","set_pid"),("ptu_","set_tut"),("pdl_","set_dl"),("pdm_","set_demo"),("pft_","set_feat"),("pst_","set_stock")]:
            if d.startswith(pr):
                pid = int(d.split("_")[1])
                st["a"] = act; st["pid"] = pid; sst(uid, st)
                prompts = {"edit_name":"Send new name:","set_pid":"Send API PID:","set_tut":"Send tutorial link:","set_dl":"Send download link:","set_demo":"Send demo link:","set_feat":"Send features text:","set_stock":"Send stock (-1, 0 or >0):"}
                nav(call, f"📝 {prompts[act]}", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data=f"pedit_{pid}", style="danger"))); return

        if d.startswith("ppl_"):
            pid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("SELECT id,duration,price FROM plans WHERE product_id=? ORDER BY id ASC", (pid,))
            plans = cur.fetchall(); c.close()
            t = "📋 <b>Pricing Plans</b>\n\n━━━━━━━━━━━━━━━\n\n"
            for pl in plans: t += f"⏰ {esc(pl['duration'])} — ₹{pl['price']}\n"
            if not plans: t += "<i>No plans</i>"
            t += "\n━━━━━━━━━━━━━━━"
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("➕ 𝑨𝒅𝒅 𝑷𝒍𝒂𝒏𝒔", callback_data=f"pap_{pid}", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data=f"pedit_{pid}", style="danger"))
            nav(call, t, m); return

        if d.startswith("pap_"):
            pid = int(d.split("_")[1])
            st["a"] = "add_plans"; st["pid"] = pid; sst(uid, st)
            nav(call, "📅 <b>Add Plans</b>\n\nFormat: <code>duration price</code>\n\n<i>Example:\n1 Day 70\n7 Days 261</i>",
                InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data=f"pedit_{pid}", style="danger"))); return

        if d.startswith("ptg_"):
            pid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("SELECT status FROM products WHERE id=?", (pid,))
            r = cur.fetchone()
            if r:
                new = "maintenance" if r["status"]=="active" else "active"
                cur.execute("UPDATE products SET status=? WHERE id=?", (new, pid)); c.commit()
                bot.answer_callback_query(call.id, f"✅ {new.upper()}", show_alert=True)
            c.close()
            call.data = f"pedit_{pid}"; on_cb(call); return

        if d.startswith("pde_"):
            pid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("DELETE FROM plans WHERE product_id=?", (pid,))
            cur.execute("DELETE FROM products WHERE id=?", (pid,))
            c.commit(); c.close()
            bot.answer_callback_query(call.id, "✅", show_alert=True)
            call.data = "ap_manage"; on_cb(call); return

        if d == "ad":
            c = db(); cur = c.cursor()
            cur.execute("SELECT id,user_id,amount,utr FROM deposits WHERE status='pending' ORDER BY id DESC LIMIT 10")
            ds = cur.fetchall(); c.close()
            if not ds: nav(call, "💰 <b>No Pending Deposits</b>", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))); return
            t = f"💰 <b>Pending: {len(ds)}</b>\n\n━━━━━━━━━━━━━━━\n\n"
            m = InlineKeyboardMarkup(row_width=1)
            for dep in ds:
                t += f"#{dep['id']} | 👤 {dep['user_id']}\n💰 ₹{dep['amount']}\n📝 <code>{esc(dep['utr'])}</code>\n\n"
                m.add(InlineKeyboardButton(f"✅ 𝑨𝒑𝒑𝒓𝒐𝒗𝒆 #{dep['id']}", callback_data=f"dap_{dep['id']}", style="success"))
                m.add(InlineKeyboardButton(f"❌ 𝑹𝒆𝒋𝒆𝒄𝒕 #{dep['id']}", callback_data=f"drj_{dep['id']}", style="danger"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, t, m); return

        if d.startswith("dap_"):
            did = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM deposits WHERE id=? AND status='pending'", (did,))
            dep = cur.fetchone()
            if not dep: c.close(); bot.answer_callback_query(call.id, "❌", show_alert=True); return
            cur.execute("UPDATE deposits SET status='approved' WHERE id=?", (did,))
            cur.execute("UPDATE users SET balance=balance+? WHERE id=?", (dep["amount"], dep["user_id"]))
            cur.execute("INSERT INTO txs(user_id,amount,type,details) VALUES(?,?,'add_money','manual')", (dep["user_id"], dep["amount"]))
            c.commit(); c.close()
            try: send(dep["user_id"], f"✅ <b>Deposit Approved</b>\n\n₹{dep['amount']} added!")
            except: pass
            bot.answer_callback_query(call.id, "✅", show_alert=True)
            call.data = "ad"; on_cb(call); return

        if d.startswith("drj_"):
            did = int(d.split("_")[1])
            st["a"] = "rej_reason"; st["did"] = did; sst(uid, st)
            nav(call, "❌ Send reason (or 'skip'):", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="ad", style="danger"))); return

        if d == "au":
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("💰 𝑨𝒅𝒅 𝑩𝒂𝒍𝒂𝒏𝒄𝒆", callback_data="uab", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, "👥 <b>Users</b>", m); return

        if d == "uab":
            st["a"] = "add_bal"; sst(uid, st)
            nav(call, "💰 Format: <code>user_id amount</code>",
                InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="au", style="danger"))); return

        if d == "atk":
            c = db(); cur = c.cursor()
            cur.execute("SELECT id,user_id,subject FROM tickets WHERE status='open' ORDER BY id DESC LIMIT 10")
            tks = cur.fetchall(); c.close()
            if not tks: nav(call, "💬 <b>No Tickets</b>", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))); return
            m = InlineKeyboardMarkup(row_width=1)
            for tk in tks: m.add(InlineKeyboardButton(f"#{tk['id']} {tk['subject'][:30]}", callback_data=f"vtk_{tk['id']}", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, f"💬 <b>Tickets: {len(tks)}</b>", m); return

        if d.startswith("vtk_"):
            tid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM tickets WHERE id=?", (tid,))
            tk = cur.fetchone(); c.close()
            if not tk: return
            t = f"💬 <b>Ticket #{tid}</b>\n\n👤 {tk['user_id']}\n📝 {esc(tk['subject'])}\n\n━━━━━━━━━━━━━━━\n\n{esc(tk['message'])}"
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("💬 𝑹𝒆𝒑𝒍𝒚", callback_data=f"rtk_{tid}", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="atk", style="danger"))
            nav(call, t, m); return

        if d.startswith("rtk_"):
            tid = int(d.split("_")[1])
            st["a"] = "ticket_reply"; st["tid"] = tid; sst(uid, st)
            nav(call, "💬 Send reply:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="atk", style="danger"))); return

        if d == "acp":
            c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM coupons ORDER BY id DESC LIMIT 20")
            cps = cur.fetchall(); c.close()
            t = f"🎟️ <b>Coupons: {len(cps)}</b>\n\n━━━━━━━━━━━━━━━\n\n"
            m = InlineKeyboardMarkup(row_width=1)
            for cp in cps:
                s = "🟢" if cp["active"] else "🔴"
                t += f"{s} <code>{cp['code']}</code> — {cp['discount']}% ({cp['used']}/{cp['max_uses']})\n"
                m.add(InlineKeyboardButton(f"{s} {cp['code']}", callback_data=f"cpv_{cp['id']}", style="primary"))
            m.add(InlineKeyboardButton("➕ 𝑵𝒆𝒘", callback_data="cpn", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, t, m); return

        if d == "cpn":
            st["a"] = "cp_code"; sst(uid, st)
            nav(call, "🎟️ Send code (3-20 A-Z 0-9):", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="acp", style="danger"))); return

        if d.startswith("cpv_"):
            cid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("SELECT * FROM coupons WHERE id=?", (cid,))
            cp = cur.fetchone(); c.close()
            if not cp: return
            t = f"🎟️ <b>{esc(cp['code'])}</b>\n\n💰 {cp['discount']}%\n📊 {cp['used']}/{cp['max_uses']}\n📌 {'🟢' if cp['active'] else '🔴'}"
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("🔴 𝑻𝒐𝒈𝒈𝒍𝒆" if cp["active"] else "🟢 𝑻𝒐𝒈𝒈𝒍𝒆", callback_data=f"cpt_{cid}", style="primary"))
            m.add(InlineKeyboardButton("🗑️ 𝑫𝒆𝒍𝒆𝒕𝒆", callback_data=f"cpd_{cid}", style="danger"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="acp", style="danger"))
            nav(call, t, m); return

        if d.startswith("cpt_"):
            cid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("UPDATE coupons SET active=1-active WHERE id=?", (cid,))
            c.commit(); c.close()
            bot.answer_callback_query(call.id, "✅", show_alert=True)
            call.data = f"cpv_{cid}"; on_cb(call); return

        if d.startswith("cpd_"):
            cid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("DELETE FROM coupons WHERE id=?", (cid,))
            c.commit(); c.close()
            bot.answer_callback_query(call.id, "✅", show_alert=True)
            call.data = "acp"; on_cb(call); return

        if d == "aprj":
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("➕ 𝑨𝒅𝒅 𝑷𝒓𝒐𝒋𝒆𝒄𝒕", callback_data="aprj_add", style="success"))
            m.add(InlineKeyboardButton("➕ 𝑨𝒅𝒅 𝑪𝒐𝒏𝒇𝒊𝒈", callback_data="acfg_add", style="success"))
            m.add(InlineKeyboardButton("📋 𝑴𝒂𝒏𝒂𝒈𝒆", callback_data="aprj_manage", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, "📁 <b>Projects Manager</b>", m); return

        if d in ("aprj_add", "acfg_add"):
            cat = "project" if d == "aprj_add" else "config"
            st["a"] = "project_file"; st["prjcat"] = cat; sst(uid, st)
            nav(call, f"📁 <b>Add {cat.upper()}</b>\n\nSend the file:",
                InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="aprj", style="danger"))); return

        if d == "aprj_manage":
            c = db(); cur = c.cursor()
            cur.execute("SELECT id,name,price,category FROM projects ORDER BY id DESC LIMIT 20")
            rows = cur.fetchall(); c.close()
            if not rows: nav(call, "📁 No projects", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="aprj", style="danger"))); return
            m = InlineKeyboardMarkup(row_width=1)
            t = "📁 <b>All Projects</b>\n\n"
            for r in rows:
                t += f"• {r['name']} — ₹{r['price']}\n"
                m.add(InlineKeyboardButton(f"🗑️ {r['name']}", callback_data=f"prjdel_{r['id']}", style="danger"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="aprj", style="danger"))
            nav(call, t, m); return

        if d.startswith("prjdel_"):
            pid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("DELETE FROM projects WHERE id=?", (pid,))
            c.commit(); c.close()
            bot.answer_callback_query(call.id, "✅", show_alert=True)
            call.data = "aprj_manage"; on_cb(call); return

        if d == "afaq":
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("➕ 𝑨𝒅𝒅 𝑭𝑨𝑸", callback_data="afaq_add", style="success"))
            m.add(InlineKeyboardButton("📋 𝑽𝒊𝒆𝒘", callback_data="afaq_view", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, "❓ <b>FAQ Manager</b>", m); return

        if d == "afaq_add":
            st["a"] = "faq_q"; sst(uid, st)
            nav(call, "❓ Send question:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="afaq", style="danger"))); return

        if d == "afaq_view":
            c = db(); cur = c.cursor()
            cur.execute("SELECT id,question,answer FROM faqs ORDER BY order_num ASC")
            rows = cur.fetchall(); c.close()
            if not rows: nav(call, "No FAQs", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="afaq", style="danger"))); return
            t = "❓ <b>All FAQs</b>\n\n"
            m = InlineKeyboardMarkup(row_width=1)
            for f in rows:
                t += f"Q: {f['question']}\nA: {f['answer'][:80]}\n\n"
                m.add(InlineKeyboardButton(f"🗑️ {f['question'][:40]}", callback_data=f"faqdel_{f['id']}", style="danger"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="afaq", style="danger"))
            nav(call, t, m); return

        if d.startswith("faqdel_"):
            fid = int(d.split("_")[1]); c = db(); cur = c.cursor()
            cur.execute("DELETE FROM faqs WHERE id=?", (fid,))
            c.commit(); c.close()
            bot.answer_callback_query(call.id, "✅", show_alert=True)
            call.data = "afaq_view"; on_cb(call); return

        if d == "am":
            menu = get_menu()
            t = f"🎛️ <b>Menu Editor</b>\n\nTotal: {len(menu)}\n\n★ Custom\n• Default\n\n"
            m = InlineKeyboardMarkup(row_width=1)
            for i, b in enumerate(menu):
                tag = "★" if b.get("id","").startswith("custom_") else "•"
                t += f"{tag} {b.get('e','')} {b.get('l','')}\n"
                m.add(InlineKeyboardButton(f"{b.get('e','')} {b.get('l','')[:25]}", callback_data=f"me_{i}", style="primary"))
            m.add(InlineKeyboardButton("➕ 𝑨𝒅𝒅 𝑪𝒖𝒔𝒕𝒐𝒎", callback_data="me_add", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, t, m); return

        if d == "me_add":
            st["a"] = "menu_emo"; sst(uid, st)
            nav(call, "➕ Step 1: Send emoji", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="am", style="danger"))); return

        if d.startswith("me_") and len(d.split("_")) == 2:
            try:
                idx = int(d.split("_")[1]); menu = get_menu()
                if idx >= len(menu): return
                b = menu[idx]
                t = f"🎛️ <b>{esc(b.get('l',''))}</b>\n\nEmoji: {esc(b.get('e',''))}\nLabel: {esc(b.get('l',''))}"
                m = InlineKeyboardMarkup(row_width=1)
                m.add(InlineKeyboardButton("🎨 𝑬𝒎𝒐𝒋𝒊", callback_data=f"mee_{idx}", style="primary"))
                m.add(InlineKeyboardButton("📝 𝑳𝒂𝒃𝒆𝒍", callback_data=f"mel_{idx}", style="primary"))
                if b.get("id","").startswith("custom_"): m.add(InlineKeyboardButton("🗑️ 𝑫𝒆𝒍𝒆𝒕𝒆", callback_data=f"med_{idx}", style="danger"))
                m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="am", style="danger"))
                nav(call, t, m)
            except: pass
            return

        if d.startswith("mee_"):
            idx = int(d.split("_")[1])
            st["a"] = "menu_edit_emoji"; st["idx"] = idx; sst(uid, st)
            nav(call, "🎨 Send emoji:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="am", style="danger"))); return

        if d.startswith("mel_"):
            idx = int(d.split("_")[1])
            st["a"] = "menu_edit_label"; st["idx"] = idx; sst(uid, st)
            nav(call, "📝 Send label:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="am", style="danger"))); return

        if d.startswith("med_"):
            idx = int(d.split("_")[1]); menu = get_menu()
            if idx < len(menu) and menu[idx].get("id","").startswith("custom_"):
                bid = menu[idx]["id"]
                menu = [b for b in menu if b.get("id") != bid]
                set_menu(menu)
                bot.answer_callback_query(call.id, "✅", show_alert=True)
            call.data = "am"; on_cb(call); return

        if d.startswith("mty_"):
            mtype = d.replace("mty_", "")
            menu = get_menu()
            bid = "custom_" + str(int(time.time()*1000))
            if mtype == "url":
                menu.append({"id": bid, "e": st.get("me_e","✦"), "l": st.get("me_l","Button"), "s": "primary", "u": st.get("me_v","")})
            else:
                menu.append({"id": bid, "e": st.get("me_e","✦"), "l": st.get("me_l","Button"), "s": "primary", "t": st.get("me_v","")})
            set_menu(menu); pst(uid)
            bot.answer_callback_query(call.id, "✅ Added!", show_alert=True)
            call.data = "am"; on_cb(call); return

        for b in get_menu():
            if b.get("id","") == d:
                if b.get("u"): bot.answer_callback_query(call.id, "🔗", url=b["u"]); return
                elif b.get("t"): nav(call, f"{b.get('e','')} <b>{esc(b.get('l',''))}</b>\n\n━━━━━━━━━━━━━━━\n\n{esc(b.get('t',''))}", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="home", style="danger"))); return

        if d == "atx":
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("👋 𝑾𝒆𝒍𝒄𝒐𝒎𝒆", callback_data="tew", style="primary"))
            m.add(InlineKeyboardButton("🏷️ 𝑩𝒂𝒅𝒈𝒆", callback_data="teb", style="primary"))
            m.add(InlineKeyboardButton("📺 𝑻𝒖𝒕𝒐𝒓𝒊𝒂𝒍 𝑳𝒊𝒏𝒌", callback_data="tet", style="primary"))
            m.add(InlineKeyboardButton("📸 𝑺𝒆𝒍𝒍𝒊𝒏𝒈 𝑷𝒓𝒐𝒐𝒇", callback_data="tes", style="primary"))
            m.add(InlineKeyboardButton("📢 𝑼𝒑𝒅𝒂𝒕𝒆 𝑪𝒉𝒂𝒏𝒏𝒆𝒍", callback_data="teu", style="primary"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, "📝 <b>Text Editor</b>", m); return

        if d == "tew": st["a"]="set_welcome"; sst(uid,st); nav(call, "👋 Welcome text (placeholders {name} {id} {bal} {orders})", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="atx", style="danger"))); return
        if d == "teb": st["a"]="set_badge"; sst(uid,st); nav(call, "🏷️ Send badge:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="atx", style="danger"))); return
        if d == "tet": st["a"]="tut_link"; sst(uid,st); nav(call, "📺 Send tutorial link:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="atx", style="danger"))); return
        if d == "tes": st["a"]="sp_link"; sst(uid,st); nav(call, "📸 Send selling proof link:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="atx", style="danger"))); return
        if d == "teu": st["a"]="upd_ch"; sst(uid,st); nav(call, "📢 Send update channel URL:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="atx", style="danger"))); return

        if d == "aapi":
            url = (gs("api_url","") or "Not Set")[:40]; key = (gs("api_key","") or "Not Set")[:15]; master = (gs("master_key","") or "Not Set")[:15]
            fgk = (gs("fg_key","") or "Not Set")[:15]; fgst = gs("fg_on","off")
            t = f"🔌 <b>API Settings</b>\n\n━━━━━━━━━━━━━━━\n📌 Product API:\nURL: <code>{esc(url)}</code>\nKey: <code>{esc(key)}</code>\nMaster: <code>{esc(master)}</code>\n\n📌 FamGateway:\nKey: <code>{esc(fgk)}</code>\nStatus: {'🟢' if fgst=='on' else '🔴'}\n━━━━━━━━━━━━━━━"
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("✏️ 𝑨𝑷𝑰 𝑼𝑹𝑳", callback_data="apu", style="primary"))
            m.add(InlineKeyboardButton("✏️ 𝑨𝑷𝑰 𝑲𝒆𝒚", callback_data="apk", style="primary"))
            m.add(InlineKeyboardButton("✏️ 𝑴𝒂𝒔𝒕𝒆𝒓 𝑲𝒆𝒚", callback_data="apm", style="primary"))
            m.add(InlineKeyboardButton("✏️ 𝑭𝒂𝒎𝑮𝒂𝒕𝒆𝒘𝒂𝒚 𝑲𝒆𝒚", callback_data="afk", style="success"))
            m.add(InlineKeyboardButton(f"{'🔴 Disable' if fgst=='on' else '🟢 Enable'} FamGateway", callback_data="aft", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, t, m); return

        if d == "apu": st["a"]="api_u"; sst(uid,st); nav(call,"✏️ Send API URL:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀",callback_data="aapi",style="danger"))); return
        if d == "apk": st["a"]="api_k"; sst(uid,st); nav(call,"✏️ Send API Key:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀",callback_data="aapi",style="danger"))); return
        if d == "apm": st["a"]="api_m"; sst(uid,st); nav(call,"✏️ Send Master Key:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀",callback_data="aapi",style="danger"))); return
        if d == "afk": st["a"]="fg_k"; sst(uid,st); nav(call,"✏️ Send FamGateway Key:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀",callback_data="aapi",style="danger"))); return

        if d == "aft":
            cur = gs("fg_on","off"); new = "off" if cur == "on" else "on"
            if new == "on":
                try: import famgateway
                except ImportError: bot.answer_callback_query(call.id, "❌ pip install famgateway", show_alert=True); return
                if not gs("fg_key",""): bot.answer_callback_query(call.id, "❌ Set key", show_alert=True); return
            ss("fg_on", new); bot.answer_callback_query(call.id, f"✅ {new.upper()}", show_alert=True)
            call.data = "aapi"; on_cb(call); return

        if d == "aai":
            active = gs("ai","groq")
            t = f"🤖 <b>AI Control</b>\n\nActive: <b>{active.upper()}</b>"
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton("⚡ 𝑮𝒓𝒐𝒒", callback_data="ais_groq", style="primary"))
            m.add(InlineKeyboardButton("💎 𝑮𝒆𝒎𝒊𝒏𝒊", callback_data="ais_gemini", style="primary"))
            m.add(InlineKeyboardButton("🧠 𝑪𝒉𝒂𝒕𝑮𝑷𝑻", callback_data="ais_openai", style="primary"))
            m.add(InlineKeyboardButton("🔑 𝑮𝒓𝒐𝒒 𝑲𝒆𝒚", callback_data="aik_groq", style="success"))
            m.add(InlineKeyboardButton("🔑 𝑮𝒆𝒎𝒊𝒏𝒊 𝑲𝒆𝒚", callback_data="aik_gemini", style="success"))
            m.add(InlineKeyboardButton("🔑 𝑶𝒑𝒆𝒏𝑨𝑰 𝑲𝒆𝒚", callback_data="aik_openai", style="success"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, t, m); return

        if d.startswith("ais_"):
            ss("ai", d.replace("ais_",""))
            bot.answer_callback_query(call.id, "✅ Switched", show_alert=True)
            call.data = "aai"; on_cb(call); return

        if d.startswith("aik_"):
            p = d.replace("aik_","")
            st["a"] = f"{p}_k"; sst(uid,st)
            nav(call, f"🔑 Send {p.upper()} API Key:",
                InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍", callback_data="aai", style="danger"))); return

        if d == "as":
            mnt = gs("maint","off"); md = gs("min_dep", 10); rf = gs("reseller_fee", 399)
            t = f"⚙️ <b>Settings</b>\n\n━━━━━━━━━━━━━━━\n🔧 Maint: {'🔴 ON' if mnt=='on' else '🟢 OFF'}\n💰 Min Deposit: ₹{md}\n🤝 Reseller Fee: ₹{rf}\n━━━━━━━━━━━━━━━"
            m = InlineKeyboardMarkup(row_width=1)
            m.add(InlineKeyboardButton(f"{'🟢 OFF' if mnt=='on' else '🔴 ON'} 𝑴𝒂𝒊𝒏𝒕", callback_data="smnt", style="danger"))
            m.add(InlineKeyboardButton("💰 𝑴𝒊𝒏 𝑫𝒆𝒑𝒐𝒔𝒊𝒕", callback_data="smd", style="primary"))
            m.add(InlineKeyboardButton("🤝 𝑹𝒆𝒔𝒆𝒍𝒍𝒆𝒓 𝑭𝒆𝒆", callback_data="srf", style="primary"))
            m.add(InlineKeyboardButton("💾 𝑩𝒂𝒄𝒌𝒖𝒑", callback_data="sbk", style="success"))
            m.add(InlineKeyboardButton("📂 𝑹𝒆𝒔𝒕𝒐𝒓𝒆", callback_data="srs", style="danger"))
            m.add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))
            nav(call, t, m); return

        if d == "smnt":
            cur = gs("maint","off"); ss("maint", "off" if cur == "on" else "on")
            bot.answer_callback_query(call.id, "✅", show_alert=True)
            call.data = "as"; on_cb(call); return

        if d == "smd": st["a"]="min_dep"; sst(uid,st); nav(call, "💰 Send min deposit:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀",callback_data="as",style="danger"))); return
        if d == "srf": st["a"]="res_fee"; sst(uid,st); nav(call, "🤝 Send reseller fee:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀",callback_data="as",style="danger"))); return

        if d == "sbk":
            try:
                with open(DB_FILE,"rb") as f: bot.send_document(call.message.chat.id, f, caption="💾 Backup")
            except Exception as e: bot.answer_callback_query(call.id, f"❌ {e}", show_alert=True)
            return

        if d == "srs": st["a"]="restore"; sst(uid,st); nav(call, "📂 Send .db file:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀",callback_data="as",style="danger"))); return

        if d == "abc": st["a"]="bc"; sst(uid,st); nav(call, "📢 Send broadcast message:", InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑪𝒂𝒏𝒄𝒆𝒍",callback_data="admin",style="danger"))); return

        if d == "aan":
            c = db(); cur = c.cursor()
            today = datetime.now().strftime('%Y-%m-%d')
            cur.execute("SELECT COALESCE(SUM(amount),0) as t FROM txs WHERE type='purchase' AND DATE(created)=?", (today,))
            rev = cur.fetchone()["t"]
            cur.execute("SELECT COUNT(*) as c FROM txs WHERE type='purchase' AND DATE(created)=?", (today,))
            ords = cur.fetchone()["c"]
            cur.execute("SELECT COUNT(*) as c FROM users"); users = cur.fetchone()["c"]
            c.close()
            t = f"📊 <b>Analytics</b>\n\n━━━━━━━━━━━━━━━\n\n📅 Today\n💰 ₹{rev}\n📦 {ords}\n\n👥 Total Users: {users}\n\n━━━━━━━━━━━━━━━"
            nav(call, t, InlineKeyboardMarkup().add(InlineKeyboardButton("◀ 𝑩𝒂𝒄𝒌", callback_data="admin", style="danger"))); return

    except Exception as e:
        log.error(f"cb {d}: {e}")
        try: bot.answer_callback_query(call.id)
        except: pass

if __name__ == "__main__":
    init_db()
    try: bot.delete_webhook(drop_pending_updates=True)
    except Exception as e: log.error(f"Webhook: {e}")
    log.info("Bot starting...")
    print("🚀 SIR ROLEX Bot is running...")
    while True:
        try: bot.infinity_polling(timeout=60, long_polling_timeout=60)
        except KeyboardInterrupt: break
        except Exception as e:
            log.error(f"Crash: {e}")
            print(f"⚠️ {e} — restarting...")
            time.sleep(5)